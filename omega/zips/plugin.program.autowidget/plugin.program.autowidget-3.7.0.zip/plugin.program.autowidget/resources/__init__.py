"""The base resources folder for AutoWidget."""
