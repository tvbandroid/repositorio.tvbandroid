# -*- coding: utf-8 -*-

import re

from platformcode import config, logger
from core.item import Item
from core import httptools, scrapertools


host = 'https://jizzbunker.com/es/'


def do_downloadpage(url, post=None, headers=None):
    data = httptools.downloadpage(url, post=post, headers=headers).data
    return data


def mainlist(item):
    return mainlist_pelis(item)


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    if not config.get_setting('ses_pin'):
        if config.get_setting('adults_password'):
            from modules import actions
            if actions.adults_password(item) == False: return

        config.set_setting('ses_pin', True)

    itemlist.append(item.clone( title = 'Buscar vídeo ...', action = 'search', search_type = 'movie', search_video = 'adult', text_color = 'orange' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'newest/' ))

    itemlist.append(item.clone( title = 'Más populares', action = 'list_all', url = host + 'straight/popular1/' ))
    itemlist.append(item.clone( title = 'Más valorados', action = 'list_all', url = host + 'straight/trending/' ))

    itemlist.append(item.clone( title = 'Por categoría', action = 'categorias', url= host + 'channels/alphabetically' ))

    return itemlist


def categorias(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|&nbsp;|<br>', '', data)

    bloque = scrapertools.find_single_match(data, '</h1>(.*?)</section>')

    matches = re.compile('<a href="(.*?)".*?<img src="(.*?)".*?alt="(.*?)"', re.DOTALL).findall(bloque)

    for url, thumb, title in matches:
        if title == 'ánal': title = 'Anal'
        elif title == 'ánime': title = 'Anime'
        elif title == 'árabe': title = 'Arabe'

        title = title.capitalize()

        itemlist.append(item.clone (action='list_all', title=title, url=url, thumbnail=thumb, text_color='moccasin' ))

    return sorted(itemlist,key=lambda x: x.title)


def list_all(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    data = re.sub(r'\n|\r|\t|&nbsp;|<br>', '', data)

    bloque = scrapertools.find_single_match(data, '</h1>(.*?)</section>')

    matches = re.compile('<a href="(.*?)".*?<img src="(.*?)".*?alt="(.*?)".*?<span class="video-card__duration">(.*?)</span>', re.DOTALL).findall(bloque)

    for url, thumb, title, duration, in matches:
        title = "[COLOR tan]%s[/COLOR] %s" % (duration, title)

        itemlist.append(item.clone (action='findvideos', title=title, url=url, thumbnail=thumb, contentType = 'movie', contentTitle = title, contentExtra='adults') )

    if itemlist:
        if '>Siguiente &rsaquo;</a>' in data:
            next_page = scrapertools.find_single_match(data, '<nav class="pagination".*?<span class="pagination__btn pagination__btn--active">.*?<a href="(.*?)".*?</nav>')

            if next_page:
                itemlist.append(item.clone (action='list_all', title='Siguientes ...', url=next_page, text_color = 'coral') )

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    if not config.get_setting('ses_pin'):
        if config.get_setting('adults_password'):
            from modules import actions
            if actions.adults_password(item) == False: return

        config.set_setting('ses_pin', True)

    data = do_downloadpage(item.url)
    data = re.sub(r"\n|\r|\t|&nbsp;|<br>|<br/>", "", data)

    matches = scrapertools.find_multiple_matches(data, 'type:\'video/mp4\',src:\'([^\']+)\'')

    for url in matches:
        itemlist.append(Item( channel = item.channel, action='play', title='', url=url, server='directo', language = 'Vo') )

    return itemlist


def search(item, texto):
    logger.info()
    try:
        config.set_setting('search_last_video', texto)

        item.url =  host + 'search?query=%s/' % (texto.replace(" ", "+"))
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
