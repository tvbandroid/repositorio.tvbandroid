#!/usr/bin/env python3

from lib.router import addon_router

addon_router()
