#!/usr/bin/env python3

from lib.navigation import run

run()
