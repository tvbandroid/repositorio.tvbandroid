# LATIN SPORTS
Simple Kodi addon that scrapes a few sports sites for live streams, replays and highlights.

Disclaimer: The author does not host or distribute any of the content displayed by this addon. The author does not have any affiliation with the content provider. This addon acts merely as a browser for sites publically available on the internet which the author has no control of.
