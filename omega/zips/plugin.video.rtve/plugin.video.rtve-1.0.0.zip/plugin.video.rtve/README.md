# plugin.video.rtve
Kodi addon RTVE. 
Entertainment, news, sports, documentaries, etc from spanish television https://www.rtve.es/play/

Complement per Kodi - XBMC.  
Toda la programación de RTVE.



