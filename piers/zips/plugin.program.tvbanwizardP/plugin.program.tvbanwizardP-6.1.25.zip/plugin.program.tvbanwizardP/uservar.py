'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/tvbandroid/repositorio.tvbandroid/master/andfiles/builds.txt'

'''#####-----Videos File-----#####'''
videos_url = ''

'''#####-----Notification File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/tvbandroid/repositorio.tvbandroid/master/buildfiles/tvban/Notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = ''

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.absolution', 'plugin.video.asgard', 'plugin.video.fenlight', 'plugin.video.free99', 'plugin.video.pov', 'plugin.video.scrubsv2', 'plugin.video.thechains', 'plugin.video.themoviedb.helper', 'repository.redwizard', 'script.module.resolveurl', 'service.subtitles.a4ksubtitles']

#Change Build Names
BUILDS = [{'Old Build': "TVban matnexompie", 'New Build': "TVban Wizard Full"},
          {'Old Build': "TVban matnexom", 'New Build': "TVban Wizard Full"},
          {'Old Build': "ArcticFuse TVban Amillans", 'New Build': "TVban Wizard Amillan"}]
          