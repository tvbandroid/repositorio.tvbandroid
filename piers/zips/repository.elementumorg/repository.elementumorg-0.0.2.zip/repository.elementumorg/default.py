import dependencies  # noqa, pylint: disable=unused-import
from lib.entries import run

run()
